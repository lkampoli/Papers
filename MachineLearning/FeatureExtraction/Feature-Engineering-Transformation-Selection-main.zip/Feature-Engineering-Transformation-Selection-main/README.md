# Feature-Engineering-Transformation-Selection
In this repository i have tried some Feature Engineering techniuques and Features transformation by using various Standadrization and Normalizations methods.
Types Of Transformation-
Normalization And Standardization
Scaling to Minimum And Maximum values
Scaling To Median And Quantiles
Guassian Transformation
Logarithmic Transformation
Reciprocal Trnasformation
Square Root Transformation
Exponential Trnasformation
Box Cox Transformation etc.

For this i have used titanic dataset for practice purpose which is got from Kaggle. 

function weights = RGS(X_train, Y_train, extra_param);  

% weights = RGS(X_train, Y_train, extra_param);
%
% Implementation of RGS algorithm, described in
%
% A. Navot, L. Shpigelman, N. Tishby, E. Vaadia. Nearest Neighbor Based Feature Selection for Regression and its
% Application to Neural Activity. Submitted to NIPS 2005.
%
% input: X_train(i,j) is the value of feature j in training instance i.
%        Y_train(i) is the label of training instance i.
%        extra_param is a struct that may contain the following parameters for the algorithm:
%             num_starts: number of starting point to use in order to avoid local maxima. The 
%                         runing time is linear in this number. (default is 2)
%
%             epochs: number of times to pass over all the training
%                     instances (default is 1)
%             k: number of neighbors (default: ceil(log2(# of instances)))
%             beta: beta is a Gaussian decay factor. (default as explained in the paper)
%             verbose: 1 for verbose, 0 otherwise (default is 0)
%
% output: weights(j) is the weight of the j's feature. higher is better.
%                  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  Written by Amir Navot & Lavi Shpigelman               
%% Date: June 3, 2005                        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if ~isfield(extra_param, 'verbose'), extra_param.verbose = 0; end
if ~isfield(extra_param, 'num_starts'), extra_param.num_starts=2;  if extra_param.verbose, disp(['num_starts = ' extra_param.num_starts]); end; end;
if ~isfield(extra_param, 'k'), extra_param.k = ceil(log2(size(X_train,1))); if extra_param.verbose, disp(['k = ' num2str(extra_param.k)]); end; end

num_starts=extra_param.num_starts;

evalFunVal = -realmax;
rand('state',sum(100*clock));
X_train_square = X_train.^2;
m=length(Y_train);
for rep = 1:num_starts,
   new_weights=RGSonce(X_train, Y_train, extra_param);
   [sorted_dists, NNs] = getLooNN(X_train, X_train_square, new_weights, 1:m);
   estY = kNNreg([], [], Y_train, new_weights, extra_param,sorted_dists, NNs);
   new_evalFunVal = -sum((Y_train-estY).^2);
  
    if new_evalFunVal >= evalFunVal,
      evalFunVal = new_evalFunVal;
      weights = new_weights;
    end;
end;



function weights = RGSonce(X_train, Y_train, extra_param);

if ~isfield(extra_param, 'k'), extra_param.k = ceil(log2(size(X_train,1))); if extra_param.verbose, disp(['k = ' num2str(extra_param.k)]); end; end
k = extra_param.k;
if ~isfield(extra_param, 'epochs'), extra_param.epochs = 1; if extra_param.verbose, disp(['epochs = ' num2str(extra_param.epochs)]); end; end
if ~isfield(extra_param, 'beta'),    
        [sorted_dists, NNs] = getLooNN(X_train, X_train.^2, ones(1,size(X_train,2)), 1:size(X_train,1));
        extra_param.beta = mean(sorted_dists(:,floor(k/2)))/2;
        if extra_param.verbose, disp(['beta = ' num2str(extra_param.beta )]); end
end

epochs = extra_param.epochs;
beta = extra_param.beta;

m = size(X_train, 1);
p = size(X_train, 2);
ws = ones(1, p);

X_train_square = X_train.^2;

t = 1;
for epoch = 1:epochs,
  perm = randperm(m);
  for pxi = 1:m,

    xi = perm(pxi);
    [sorted_dists, NNs] = getLooNN(X_train, X_train_square, ws.^2, xi);

    coef = zeros(k, 1);
    fhw = 0;
    du = zeros(1,p);
    dzw = zeros(1,p);
    for ki = 1:k,
      coef(ki) = exp(-sorted_dists(ki) / extra_param.beta);
      fhw = fhw + Y_train(NNs(ki)) .* coef(ki);
      du = du + ws .* (X_train(xi,:)- X_train(NNs(ki),:)).^2 * Y_train(NNs(ki)) * coef(ki);
      dzw = dzw + ws .* (X_train(xi,:)- X_train(NNs(ki),:)).^2 * coef(ki);
    end;
    scoef = sum(coef);
    u = fhw;
    fhw = fhw ./ scoef;
    zw = scoef;
    du = du *(-4/beta);
    dzw = dzw *(-4/beta);
    
    ws = ws +get_eta(t)*(Y_train(xi)-fhw)*(zw*du - u*dzw) / zw^2;
    t = t+1;
  end
end
weights = ws.^2;


function eta=get_eta(t);
eta = 1;


